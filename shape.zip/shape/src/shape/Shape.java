package shape;

public interface Shape {
public double calculateArea(int ...d);
}

