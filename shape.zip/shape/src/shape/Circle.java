package shape;

public class Circle implements Shape {
	public double calculateArea(int ...d) {
		double area=0;
		area=Math.PI*d[0]*d[0];
		return area;
	}

}
