package shape;

public class Triangle implements Shape{
	public double calculateArea(int ...d)
	{
		double area=0;
		area=0.5*d[0]*d[1];
		return area;
	}

}
