package shape;

public class Rectangle implements Shape{
	public double calculateArea(int ...d)
	{
		double area=0;
		
			area=d[0]*d[1];
		
		return area;
	}
	

}
