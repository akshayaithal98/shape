package shape;

public class Square implements Shape{
	public double calculateArea(int ...d) {
		double area=0;
		area=d[0]*d[0];
		return area;
		
	}

}
