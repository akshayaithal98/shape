package shape;
public class Main{
	public static void main(String[] args)
	{
		Square s=new Square();
		Rectangle r=new Rectangle();
		Circle c=new Circle();
		Triangle t=new Triangle();
		System.out.println("Area of square:"+s.calculateArea(3));
		System.out.println("Area of rectangle:"+r.calculateArea(3,4));
		System.out.println("Area of circle:"+c.calculateArea(3));
		System.out.println("Area of triangle:"+t.calculateArea(3,4));
	}
}
